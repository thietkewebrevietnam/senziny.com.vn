<?php
	
	$sample = Inspius_Sample_Data::instance();

	$script_url = INSPIUS_PLUGIN_URI . 'samples/js/script.js';
	$style_url = INSPIUS_PLUGIN_URI . 'samples/css/style.css';

	$attr_button = array(
        'data-confirm="' . __( 'Are you sure you want to install', 'inspius_core' ) . '"',
        'href="#"',
        'class="button button-primary begin-install"',
    );
	$is_regenerate_thumbnail = is_plugin_active( 'regenerate-thumbnails/regenerate-thumbnails.php' );
	$link_regenerate_thumbnail = admin_url( 'plugin-install.php?tab=plugin-information&amp;plugin=regenerate-thumbnails&amp;TB_iframe=true&amp;width=830&amp;height=472' );
	if( $is_regenerate_thumbnail ){
		$link_regenerate_thumbnail = admin_url( 'tools.php?page=regenerate-thumbnails' );
	}

	$url_images = INSPIUS_PLUGIN_URI . 'assets/images/';

?>
<link rel="stylesheet" href="<?php echo esc_url( $style_url ); ?>">
<div id="inspius_sample_data" class="inspius_sample_data">
	<div class="header">
		<a href="http://inspius.com/">
			<img src="http://inspius.com/img/logo2.png" alt="inspius">
		</a>
	</div>
	<?php if(false): ?>
	<div class="box-content">
		<h3>Information</h3>
		<div class="inner desc">
			<p>Importing demo data (post, pages, images, theme settings, ...) is the easiest way to setup your theme. It will allow you to quickly edit everything instead of creating content from scratch. When you import the data following things will happen:</p>
		   	<ul>
		   		<li>No existing posts, pages, categories, images, custom post types or any other data will be deleted or modified .</li>
		   		<li>Posts, pages, some images, some widgets and menus will get imported (if chosen accordingly).</li>
		   	</ul>
			<p>Please click import only once and wait, it can take a couple of minutes</p>
		</div>
	</div>
	<?php endif; ?>
    <div class="box-content">
    	<h3>THEME CONFIGURATION</h3>
    	<div class="success success-sample">
    		<strong>Sucessfully imported demo data! </strong> Now, please install and run 
    		<a href="<?php echo esc_url( $link_regenerate_thumbnail ); ?>" 
    			class="<?php echo esc_attr( ($is_regenerate_thumbnail ) ? '' : 'thickbox' ); ?>" title="Regenerate Thumbnails">
    			Regenerate Thumbnails
    		</a> 
    		plugin once.
    	</div>
    	<div class="success success-config">
    		<strong>Sucessfully config demo data.</strong>
    	</div>
    	<div class="loading">
    		Loading... this could take a couple of minutes, please wait until you get completion message
    	</div>
    	<div class="inner">
			<ul id="inspius-list-demo" class="inspius-list-demo">
				<li data-style="cigarette-1" class="active">
					<img src="<?php echo esc_url( $url_images . 'cigarette-1.png' ); ?>">
				</li>
				<li data-style="cigarette-2">
					<img src="<?php echo esc_url( $url_images . 'cigarette-2.png' ); ?>">
				</li>
				<li data-style="cigarette-3">
					<img src="<?php echo esc_url( $url_images . 'cigarette-3.png' ); ?>">
				</li>
			</ul>

			<input id="inspius-theme-style" type="hidden" value="cigarette-1">
	    	<?php $sample->get_list_action(); ?>
		    <div class="button-action">
		        <button <?php echo implode( ' ', $attr_button ); ?>><?php _e( 'Setup Theme', 'inspius_core' ) ?></button>
		    </div>
		</div>
    </div>
</div>

<script type="text/javascript" src="<?php echo esc_url( $script_url ); ?>"></script>