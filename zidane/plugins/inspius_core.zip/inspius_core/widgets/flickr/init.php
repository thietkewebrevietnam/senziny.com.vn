<?php

class Inspius_Widget_Flickr extends WP_Widget {

	private $prefix;

	public function __construct() {

		$widget_options = array(
			'description' => __( 'Flickr photo stream from an ID', 'inspius_core' )
		);
		parent::__construct( $this->prefix, __( 'Inspius Flickr Badge', 'inspius_core' ), $widget_options );

	}

	public function widget( $args, $instance ) {
		$before_widget = $title = $before_title = $after_title =
		$count = $display = $type = $flickr_id = $after_widget = '';
		extract( $args );
		$cur_arg = array(
			'title'     => $instance['title'],
			'type'      => empty( $instance['type'] ) ? 'user' : $instance['type'],
			'flickr_id' => $instance['flickr_id'],
			'count'     => (int) $instance['count'],
			'display'   => empty( $instance['display'] ) ? 'latest' : $instance['display'],
		);
		extract( $cur_arg );

		// print the before widget
		echo $before_widget;

		if ( $title ) {
			echo $before_title . $title . $after_title;
		}

		echo "<div class='flickr-gallery'>";

		$protocol = is_ssl() ? 'https' : 'http';

		// If the widget have an ID, we can continue
		if ( ! empty( $instance['flickr_id'] ) ) {
			echo "<script type='text/javascript' src='$protocol://www.flickr.com/badge_code_v2.gne?count=$count&amp;display=$display&amp;size=s&amp;layout=x&amp;source=$type&amp;$type=$flickr_id'></script>";
		} else {
			echo '<p>' . __( 'Please provide an Flickr ID', 'inspius_core' ) . '</p>';
		}

		echo '</div>';
		echo $after_widget;
	}

	public function update( $new_instance, $old_instance ) {
		$instance              = $old_instance;
		$instance['type']      = strip_tags( $new_instance['type'] );
		$instance['flickr_id'] = strip_tags( $new_instance['flickr_id'] );
		$instance['count']     = (int) $new_instance['count'];
		$instance['display']   = strip_tags( $new_instance['display'] );
		$instance['size']      = strip_tags( $new_instance['size'] );
		$instance['title']     = strip_tags( $new_instance['title'] );

		return $instance;
	}

	public function form( $instance ) {

		$defaults = array(
			'title'     => esc_attr__( 'Flickr Widget', 'inspius_core' ),
			'type'      => 'user',
			'flickr_id' => '', // 71865026@N00
			'count'     => 9,
			'display'   => 'display',
		);

		$instance = wp_parse_args( (array) $instance, $defaults );

		$types    = array(
			'user'  => esc_attr__( 'User', 'inspius_core' ),
			'group' => esc_attr__( 'Group', 'inspius_core' )
		);
		$displays = array(
			'latest' => esc_attr__( 'Latest', 'inspius_core' ),
			'random' => esc_attr__( 'Random', 'inspius_core' )
		);

		?>

		<p>
			<label
				for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'inspius_core' ); ?></label><br>
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>"
			       name="<?php echo $this->get_field_name( 'title' ); ?>" type="text"
			       value="<?php echo esc_attr( $instance['title'] ); ?>"/>
		</p>
		<p>
			<label
				for="<?php echo $this->get_field_id( 'type' ); ?>"><?php _e( 'Type:', 'inspius_core' ); ?></label><br>
			<select id="<?php echo $this->get_field_id( 'type' ); ?>"
			        name="<?php echo $this->get_field_name( 'type' ); ?>">
				<?php foreach ( $types as $k => $v ) { ?>
					<option
						value="<?php echo esc_attr( $k ); ?>" <?php selected( $instance['type'], $k ); ?>><?php echo esc_html( $v ); ?></option>
					<br>
				<?php } ?>
			</select>
		</p>
		<p>
			<label
				for="<?php echo $this->get_field_id( 'flickr_id' ); ?>"><?php _e( 'Flickr ID:', 'inspius_core' ); ?></label><br>
			<input id="<?php echo $this->get_field_id( 'flickr_id' ); ?>"
			       name="<?php echo $this->get_field_name( 'flickr_id' ); ?>" type="text"
			       value="<?php echo esc_attr( $instance['flickr_id'] ); ?>"/>
		</p>
		<p>
			<label
				for="<?php echo $this->get_field_id( 'count' ); ?>"><?php _e( 'Number:', 'inspius_core' ); ?></label><br>
			<input class="column-last" id="<?php echo $this->get_field_id( 'count' ); ?>"
			       name="<?php echo $this->get_field_name( 'count' ); ?>" type="text"
			       value="<?php echo esc_attr( $instance['count'] ); ?>" size="3"/>
		</p>
		<p>
			<label
				for="<?php echo $this->get_field_id( 'display' ); ?>"><?php _e( 'Display Method:', 'inspius_core' ); ?></label><br>
			<select id="<?php echo $this->get_field_id( 'display' ); ?>"
			        name="<?php echo $this->get_field_name( 'display' ); ?>">
				<?php foreach ( $displays as $k => $v ) { ?>
					<option
						value="<?php echo esc_attr( $k ); ?>" <?php selected( $instance['display'], $k ); ?>><?php echo esc_html( $v ); ?></option>
				<?php } ?>
			</select>
		</p>

		<?php
	}
}