<?php

class Inspius_Widgets_Core {

	private $widgets = array();

	public function __construct() {
		$this->add_widgets( array(
			'Woocommerce_Category_Accordion',
			'Flickr',
			'Twitter',
		) );

		add_action( 'widgets_init', array( $this, 'init_widgets' ) );
	}

	public function init_widgets() {
		if ( ! empty( $this->widgets ) ) {
			foreach ( $this->widgets as $widget ) {
				$class_name = 'Inspius_Widget_' . $widget;
				register_widget( $class_name );
			}
		}
	}

	public function add_widgets( $widgets ) {
		if ( ! empty( $widgets ) ) {
			foreach ( $widgets as $widget ) {
				if ( ! empty( $widget ) ) {
					$file_name = str_replace( '_', '-', strtolower( $widget ) );
					if ( is_file( INSPIUS_PLUGIN_URL . 'widgets/' . $file_name . '/init.php' ) ) {
						include_once( INSPIUS_PLUGIN_URL . 'widgets/' . $file_name . '/init.php' );
						$this->widgets[] = $widget;
					}
				}
			}
		}
	}


}

new Inspius_Widgets_Core();
