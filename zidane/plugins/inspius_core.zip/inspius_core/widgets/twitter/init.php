<?php

class Inspius_Widget_Twitter extends WP_Widget {
	private $prefix;

	/**
	 *  Set up the widget's unique name, ID, class, description, and other options.
	 */
	public function __construct() {
		$this->prefix = 'IS_twitter';

		parent::__construct(
			$this->prefix,
			__( 'Inspius Twitter', 'inspius_core' ),
			array(
				'description' => __( 'A widget to display Twitter feed.', 'inspius_core' )
			)
		);
	}


	public function widget( $args, $instance ) {

		$title            = $instance['title'];
		$twitter_username = $instance['twitter_username'];
		$count            = (int) $instance['count'];
		$replies_excl     = true;

		$consumer_key        = '1oEnIfnFjgNNkeR7iANRdo0iz';
		$consumer_secret     = '5Gji7rmAVmg3ZuyXKzVftT0dHzL2aoL2CA0btFP9zxfQ7cADaE';
		$access_token        = '4642267220-y4l0YJcfJem2mawiPcUuy0AwY0aaoELkwbhFo9x';
		$access_token_secret = 'JY8WCPTTkq3aLRJUVsJdU48uCptKGgimreRcGWdTJucgP';


		echo $args['before_widget'];

		if ( $title ) {
			echo $args['before_title'] . $title . $args['after_title'];
		}

		$trans_name  = 'list-tweets-' . $twitter_username;
		$backup_name = $trans_name . '-backup';
		if ( false === ( $tweets = get_transient( $trans_name ) ) ) :
			require_once 'twitteroauth/twitteroauth.php';

			$api_call       = new TwitterOAuth( $consumer_key, $consumer_secret, $access_token, $access_token_secret );
			$total_to_fetch = ( $replies_excl ) ? max( 50, $count * 3 ) : $count;

			$fetched_tweets = $api_call->get(
				'statuses/user_timeline', array(
					'screen_name'  => $twitter_username,
					'count'        => $total_to_fetch,
					'replies_excl' => $replies_excl
				)
			);

			if ( $api_call->http_code != 200 ) :
				$tweets[] = get_option( $backup_name );
			else :
				$limit_to_display = min( $count, count( $fetched_tweets ) );

				for ( $i = 0; $i < $limit_to_display; $i ++ ) :
					$tweet       = $fetched_tweets[ $i ];
					$name        = $tweet->user->name;
					$screen_name = $tweet->user->screen_name;
					$permalink   = 'https://twitter.com/' . $name . '/status/' . $tweet->id_str;
					$tweet_id    = $tweet->id_str;
					if ( is_ssl() ) {
						$image = esc_url( ( isset( $tweet->retweeted_status ) ) ? $tweet->retweeted_status->user->profile_image_url_https : $tweet->user->profile_image_url_https );
					} else {
						$image = esc_url( ( isset( $tweet->retweeted_status ) ) ? $tweet->retweeted_status->user->profile_image_url : $tweet->user->profile_image_url );
					}
					//$image = $tweet->user->profile_image_url;
					$text     = $this->sanitize_links( $tweet );
					$time     = $tweet->created_at;
					$time     = date_parse( $time );
					$uTime    = mktime( $time['hour'], $time['minute'], $time['second'], $time['month'], $time['day'], $time['year'] );
					$tweets[] = array(
						'text'            => $text,
						'scr_name'        => $screen_name,
						'favourite_count' => $tweet->favorite_count,
						'retweet_count'   => $tweet->retweet_count,
						'name'            => $name,
						'permalink'       => $permalink,
						'image'           => $image,
						'time'            => $uTime,
						'tweet_id'        => $tweet_id
					);
				endfor;
				set_transient( $trans_name, $tweets, 60 * 4 );
				update_option( $backup_name, $tweets );
			endif;
		endif;

		/** include template */
		?>
			<ul class="is-widget-twitter">
				<?php if ( $tweets ): ?>
					<?php foreach ( $tweets as $t ) : ?>
						<?php 
							/*
							 * $t['image'] : Image URL
							 * $t['text']  : Content
							 * $t['time']  : 
							 * $t['name']  : username
							 * $t['tweet_id']
							 */
							$link_twitter = "https://twitter.com/{$twitter_username}";
						?>
						<li class="twitter-item">
							<div class="pull-left">
								<i class="icon-social-twitter"></i>
							</div>
							<div class="content">
								<a class="title" href="<?php echo esc_url( $link_twitter ); ?>" target="_blank">
									@<?php echo esc_html( $t['name'] ); ?>:
								</a>
								<?php echo wp_kses_post( $t['text'] ); ?>
							</div>
						</li>

					<?php endforeach; ?>

				<?php else : ?>
					<h4><?php _e( 'Waiting for twitter.com...', 'inspius' ); ?></h4>
				<?php endif; ?>
			</ul>
		<?php


		/** Close the output of the widget. */
		echo $args['after_widget'];

	}

	private function twitter_time_diff( $from, $to = '' ) {
		$diff    = human_time_diff( $from, $to );
		$replace = array(
			__( ' hour', 'inspius_core' )    => 'h',
			__( ' hours', 'inspius_core' )   => 'h',
			__( ' day', 'inspius_core' )     => 'd',
			__( ' days', 'inspius_core' )    => 'd',
			__( ' minute', 'inspius_core' )  => 'm',
			__( ' minutes', 'inspius_core' ) => 'm',
			__( ' second', 'inspius_core' )  => 's',
			__( ' seconds', 'inspius_core' ) => 's',
		);

		return strtr( $diff, $replace );
	}

	public function update( $new_instance, $old_instance ) {

		$instance = $old_instance;

		$instance['title']            = strip_tags( $new_instance['title'] );
		$instance['twitter_username'] = strip_tags( $new_instance['twitter_username'] );
		$instance['count']            = (int) $new_instance['count'];

		return $instance;

	}

	function form( $instance ) {

		/** Set up the default form values. */
		$defaults = array(
			'title'            => __( 'Inspius Twitter', 'inspius_core' ),
			'twitter_username' => 'inspius_core',
			'count'            => '3',
		);
		$instance = wp_parse_args( (array) $instance, $defaults );
		?>

		<p>
			<label
				for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'inspius_core' ); ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>"
			       name="<?php echo $this->get_field_name( 'title' ); ?>"
			       value="<?php echo esc_attr( $instance['title'] ); ?>"/>
		</p>

		<p>
			<label
				for="<?php echo $this->get_field_id( 'twitter_username' ); ?>"><?php _e( 'Twitter Username:', 'inspius_core' ); ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'twitter_widget_id' ); ?>"
			       name="<?php echo $this->get_field_name( 'twitter_username' ); ?>"
			       value="<?php echo esc_attr( $instance['twitter_username'] ); ?>"/>
		</p>

		<p>
			<label
				for="<?php echo $this->get_field_id( 'count' ); ?>"><?php _e( 'Number of twitter to display:', 'inspius_core' ); ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'count' ); ?>"
			       name="<?php echo $this->get_field_name( 'count' ); ?>"
			       value="<?php echo esc_attr( $instance['count'] ); ?>"/>
		</p>
		<?php
	}


	private function sanitize_links( $tweet ) {
		if ( isset( $tweet->retweeted_status ) ) {
			$rt_section = current( explode( ":", $tweet->text ) );
			$text       = $rt_section . ": ";
			$text .= $tweet->retweeted_status->text;
		} else {
			$text = $tweet->text;
		}
		$text = preg_replace( '/((http)+(s)?:\/\/[^<>\s]+)/i', '<a href="$0" target="_blank" rel="nofollow">$0</a>', $text );
		$text = preg_replace( '/[@]+([A-Za-z0-9-_]+)/', '<a href="https://twitter.com/$1" target="_blank" rel="nofollow">@$1</a>', $text );
		$text = preg_replace( '/[#]+([A-Za-z0-9-_]+)/', '<a href="https://twitter.com/search?q=%23$1" target="_blank" rel="nofollow">$0</a>', $text );

		return $text;
	}
}
