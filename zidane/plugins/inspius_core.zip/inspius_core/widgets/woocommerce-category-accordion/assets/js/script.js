(function( $ ){
	"use strict";
    var InspiusWidgetWoocommerceCategoryAccordion = {
    	init: function(){
    		$('.categories_accordion .parent').toggle(function() {
    			InspiusWidgetWoocommerceCategoryAccordion.eventClick($(this),'down');
    		}, function() {
    			InspiusWidgetWoocommerceCategoryAccordion.eventClick($(this),'up');
    		});

    	},
    	eventClick: function(element,event){
    		var container = element.next();
    		if(event=='up'){
    			element.removeClass('show');
    			container.slideUp('400');
    		}else{
    			element.addClass('show');
    			container.slideDown('400');
    		}
    	}
	}

    $(document).ready(function() {
    	InspiusWidgetWoocommerceCategoryAccordion.init();
    });
})( jQuery );