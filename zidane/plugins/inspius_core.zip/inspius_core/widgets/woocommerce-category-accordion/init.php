<?php
class Inspius_Widget_Woocommerce_Category_Accordion extends WP_Widget {

	private $settings = array( 'title', 'iswca_count', 'exclude_tree', 'hide_empty', 'sortby', 'order', 'ac_speed' );

	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'register_scripts' ) );

		$widget_ops = array( 'description' => __( 'list WooCommerce product categories and subcategories into a toggle accordion.', 'inspius_core' ) );
		parent::__construct( false, __( 'Inspius Woocommerce Category Accordion', 'inspius_core' ), $widget_ops );

	}

	public function register_scripts() {
		$uri = INSPIUS_PLUGIN_URI . 'widgets/woocommerce-category-accordion/assets/';
		wp_enqueue_script( 'iswca_script', $uri . 'js/script.js', array( 'jquery' ) );
	}

	public function widget( $args, $instance ) {
		$sortby = $after_widget = $show_count = $depth =
		$ac_speed = $hide_empty =
		$exclude_tree = $title = $before_widget =
		$before_title = $after_title = '';

		extract( $args );

		$instance = $this->category_accordion_defaults( $instance );

		extract( $instance );

		echo $before_widget;
			echo $before_title;
			if ( $title ) {
				echo $title;
			}
			echo $after_title;

		global $wp_query;
		global $post, $product;

		$exclude_tree = esc_attr( $exclude_tree );
		$hide_empty = esc_attr( $hide_empty );
		$depth = esc_attr( $depth );
		$instance_categories = get_terms( 'product_cat', '&parent=0&exclude=' . $exclude_tree . '' );

		if ( is_array( $instance_categories ) ) {
			foreach ( $instance_categories as $categories ) {
				$term_id[] = $categories->term_id;
				$term_name = $categories->name;
			}
		}

		if ( ! empty( $post->ID ) ) {
			$terms = get_the_terms( $post->ID, 'product_cat' );
		} else {
			$terms = "";
		}

		if ( is_array( $terms ) ) {
			foreach ( $terms as $term ) {
				$_cat = $term->term_id;
				break;
			}
		}


		/*For current category highlight*/
		$current_cat = array();
		$cat = $wp_query->get_queried_object();
		if ( ! empty( $cat->term_id ) ) {
			$current_cat = $cat->term_id;
		} else {
			$_cat_id = "1";
			if ( isset( $term->term_id ) ) {
				$_cat = $term->term_id;
				if ( ! empty( $_cat ) ) {
					$_cat_id = $_cat;
				} else {
					$_cat_id = 1;
				}
			}
			if ( is_shop() ) {
				$_cat_id = "1";
			}
		}
		?>
		
		<ul class="categories_accordion">
			<?php 
				$show_count = esc_attr( $show_count );
				$subcat_args = array(
					'taxonomy'         => 'product_cat',
					'title_li'         => '',
					'menu_order'       => 'asc',
					'depth'            => $depth,
					'show_count'       => $show_count,
					'hide_empty'       => $hide_empty,
					'echo'             => false,
					'exclude'          => $exclude_tree,
					'show_option_none' => __( 'No Categories Found', 'inspius_core' ),
					'link_after'       => '',
				);
				
				$subcategories = wp_list_categories( $subcat_args );
				$subcategories = str_replace( '<ul', '<span class="parent"></span><ul', $subcategories );
				$subcategories = preg_replace( '/<\/a> \(([0-9]+)\)/', ' <span class="count">(\\1)</span></a>', $subcategories );
				
				if ( $subcategories ) { 
					echo $subcategories; 
				}
			?>
		</ul>
		<?php

		echo $after_widget;

	}

	public function update( $new_instance, $old_instance ) {
		$new_instance = $this->category_accordion_defaults( $new_instance );
		return $new_instance;

	}

	private function category_accordion_defaults( $instance ) {
		$defaults = $this->cat_accordion_get_settings();
		$instance = wp_parse_args( $instance, $defaults );
		if ( $instance['show_count'] == "" ) {
			$instance['show_count'] = $defaults['show_count'];
		}
		if ( $instance['hide_empty'] == "" ) {
			$instance['hide_empty'] = $defaults['hide_empty'];
		}
		
		if ( $instance['depth'] == "" ) {
			$instance['depth'] = $defaults['depth'];
		}

		return $instance;

	}

	private function cat_accordion_get_settings() {

		$settings 					= array_fill_keys( $this->settings, '' );
		$settings['title'] 			= "Categories";
		$settings['show_count'] 	= 0;
		$settings['exclude_tree'] 	= "";
		$settings['hide_empty'] 	= 0;
		$settings['ac_speed'] 		= 300;
		$settings['depth'] 			= 0;
		return $settings;
	}

	public function form( $instance ) {
		$show_count = $hide_empty  = $depth = '';

		$instance = $this->category_accordion_defaults( $instance );

		extract( $instance );
		?>
		<p>
			<label
				for="<?php echo $this->get_field_id( 'title' ); ?>"><?php echo __( 'Title: ', 'inspius_core' ); ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>"
			       name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php if ( isset( $title ) )
				echo esc_attr( $title ) ?>"/>
		</p>
		<p>
			<input type="checkbox"
			       name="<?php echo $this->get_field_name( 'show_count' ); ?>" <?php if ( esc_attr( $show_count ) ) {
				echo 'checked="checked"';
			} ?> class="" size="4" id="<?php echo $this->get_field_id( 'show_count' ); ?>"/>
			<label
				for="<?php echo $this->get_field_id( 'show_count' ); ?>"><?php _e( 'Enable Products Count', 'inspius_core' ); ?></label>
		</p>
		<p>
			<input type="checkbox"
			       name="<?php echo $this->get_field_name( 'hide_empty' ); ?>" <?php if ( esc_attr( $hide_empty ) ) {
				echo 'checked="checked"';
			} ?> class="" size="4" id="<?php echo $this->get_field_id( 'hide_empty' ); ?>"/>
			<label
				for="<?php echo $this->get_field_id( 'hide_empty' ); ?>"><?php _e( 'Hide If Empty', 'inspius_core' ); ?></label>
		</p>
		
		<p>
			<label for="<?php echo $this->get_field_id( 'depth' ); ?>"><?php _e( 'Level:', 'inspius_core' ); ?>
				<select class='widefat' id="<?php echo $this->get_field_id( 'depth' ); ?>"
				        name="<?php echo $this->get_field_name( 'depth' ); ?>">
					<?php for ( $i = 0; $i <= 10; $i ++ ) : ?>
						<option
							value="<?php echo $i; ?>" <?php echo ( $i == $depth ) ? "selected='selected'" : ""; ?>><?php echo $i; ?></option>
					<?php endfor; ?>
				</select>
			</label>
			<small>0 -> show all levels</small>
		</p>
		<p>
			<label
				for="<?php echo $this->get_field_id( 'exclude_tree' ); ?>"><?php echo __( 'Exclude Category (ID): ', 'inspius_core' );
				?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'exclude_tree' ); ?>"
			       name="<?php echo $this->get_field_name( 'exclude_tree' ); ?>"
			       value="<?php if ( isset( $exclude_tree ) )
				       echo esc_attr( $exclude_tree ) ?>"/>
			<small>category IDs, separated by commas.</small>
		</p>
		<?php
	}
}
