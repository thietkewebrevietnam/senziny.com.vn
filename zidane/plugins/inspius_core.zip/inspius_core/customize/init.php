<?php

class Inspius_Customize_Base {

	public $config;

	public function __construct() {
		$this->init_hooks();
		$this->load_xml();

	}

	private function init_hooks() {
		add_filter( 'customize_section', array( $this, 'set_section' ) );
	}

	public function set_section( $sections ) {

		foreach ( $this->config as $key => $section ) {
			$output               = array();
			$output['title']      = (string) $section->attributes()->title;
			$output['subsection'] = true;
			$fields               = array();
			$i                    = 0;
			foreach ( $section->control as $k => $control ) {
				$fields[] = array(
					'id'       => (string) $control->id,
					'type'     => (string) $control->type,
					'title'    => (string) $control->title,
					'subtitle' => (string) $control->subtitle,
					'desc'     => (string) $control->desc,
					'class'    => (string) $control->class,
				);

				$fields = $this->check_required( $fields, $control->requireds, $i );
				$fields = $this->check_type( $control->type, $fields, $control, $i );
				$i ++;
			}

			$output['fields'] = $fields;
			$sections[]       = $output;
		}
		return $sections;

	}

	private function load_xml() {
		$this->config = simplexml_load_file( INSPIUS_PLUGIN_URL . 'customize.xml' );
	}

	private function check_required( $fields, $req, $i ) {
		$required = array();

		if ( ! empty( $req->required->id ) ) {
			foreach ( $req->required as $key => $requir ) {
				for ( $j = 0; $j < $i; $j ++ ) {
					if ( $fields[ $j ]['id'] == (string) $requir->id ) {
						switch ( $requir->value ) {
							case "true":
								$value = true;
								break;
							case "false":
								$value = false;
								break;
							default:
								$value = (string) $requir->value;
						}
						$required[] = array(
							(string) $requir->id,
							(string) $requir->key,
							$value
						);
					}
				}
			}

			if ( ! is_null( $required ) ) {
				$fields[ $i ]["required"] = $required;
			}

		}

		return $fields;

	}

	private function check_type( $type, $fields, $control, $i ) {

		switch ( $type ) {
			case 'text':
				$fields = $this->set_text_fields( $fields, $control, $i );
				break;
			case 'color':
				$fields = $this->set_color_fielsd( $fields, $control, $i );
				break;
			case 'media':
				$fields[ $i ]['url'] = true;
				break;
			case 'switch':
				$fields = $this->set_button_set_fields( $fields, $control, $i );
				break;
			case 'number':
				$fields = $this->set_spinner_fields( $fields, $control, $i );
				break;
			case 'pattern':
				$fields = $this->set_pattern_fields( $fields, $control, $i );
				break;
			case 'layout':
				$fields = $this->set_layout_fields( $fields, $i );
				break;
			case 'googlefont':
				$fields = $this->set_googlefont_fields( $fields, $control, $i );
				break;
			default:
		}

		return $fields;

	}

	private function set_googlefont_fields( $fields, $control, $i ) {

		$fields[ $i ]['type']           = 'typography';
		$fields[ $i ]['word-spacing']   = true;
		$fields[ $i ]['letter-spacing'] = true;
		$fields[ $i ]['text-transform'] = true;

		if ( $control->selector != "" ) {
			$fields[ $i ]['output'] = (string) $control->selector;
		}

		return $fields;
	}

	private function set_layout_fields( $fields, $i ) {

		$fields[ $i ]['type']             = 'button_set';
		$fields[ $i ]['id']               = 'layout_body';
		$fields[ $i ]['title']            = 'Layout';
		$fields[ $i ]['default']          = 'wide';
		$fields[ $i ]['options']["wide"]  = "Wide";
		$fields[ $i ]['options']["boxed"] = "Boxed";

		return $fields;
	}

	private function set_text_fields( $fields, $control, $i ) {
		$fields[ $i ]['default'] = (string) $control->default;

		return $fields;
	}

	private function set_color_fielsd( $fields, $control, $i ) {

		$fields[ $i ]['type']                              = 'color_rgba';
		$fields[ $i ]['options']['show_input']             = true;
		$fields[ $i ]['options']['show_initial']           = true;
		$fields[ $i ]['options']['show_alpha']             = true;
		$fields[ $i ]['options']['show_palette']           = true;
		$fields[ $i ]['options']['show_palette_only']      = false;
		$fields[ $i ]['options']['show_selection_palette'] = true;
		$fields[ $i ]['options']['max_palette_size']       = 10;
		$fields[ $i ]['options']['allow_empty']            = true;
		$fields[ $i ]['options']['clickout_fires_change']  = false;
		$fields[ $i ]['options']['show_buttons']           = true;
		$fields[ $i ]['options']['use_extended_classes']   = true;
		$fields[ $i ]['options']['palette']                = null;

		if ( $control->default != "" ) {
			$fields[ $i ]['default']['color'] = (string) $control->default;
		}
		if ( $control->outputs != "" ) {
			foreach ( $control->outputs->output as $key => $output ) {
				$fields[ $i ]['output']["$output->attr"] = "$output->class";
			}
		}

		return $fields;

	}

	private function set_button_set_fields( $fields, $control, $i ) {

		$fields[ $i ]['type'] = 'button_set';

		if ( $control->multi == 'true' ) {
			$fields[ $i ]['multi'] = true;
		}
		$fields[ $i ]['default'] = (string) $control->default;
		foreach ( $control->options->option as $key => $option ) {
			$value                             = $option->attributes();
			$fields[ $i ]['options']["$value"] = (string) $option;
		}

		return $fields;

	}

	private function set_spinner_fields( $fields, $control, $i ) {

		$fields[ $i ]['type']    = 'spinner';
		$fields[ $i ]['default'] = (string) $control->default;
		$fields[ $i ]['min']     = (string) $control->min;
		$fields[ $i ]['step']    = (string) $control->step;
		$fields[ $i ]['max']     = (string) $control->max;

		return $fields;
	}

	private function set_pattern_fields( $fields, $control, $i ) {

		$fields[ $i ]['type'] = 'image_select';
		$imgs                 = array();
		$files                = glob( get_template_directory() . '/images/pattern/*' );

		if ( isset( $files ) && ! empty( $files ) ) {
			foreach ( $files as $dir ) {
				if ( preg_match( "#.png|.jpg|.gif#", $dir ) ) {
					$url_img          = get_template_directory_uri() . '/images/pattern/' . wp_basename( $dir );
					$imgs[ $url_img ] = array(
						'img' => $url_img,
					);
				}
			}
		}

		if ( $control->outputs != "" ) {
			foreach ( $control->outputs->output as $key => $output ) {
				$fields[ $i ]['output']["$output->attr"] = "$output->class";
			}
		}

		$fields[ $i ]['options'] = $imgs;
		$fields[ $i ]['default'] = (string) $control->default;
		$fields[ $i ]['width']   = 50;
		$fields[ $i ]['height']  = 50;

		return $fields;
	}

}

new Inspius_Customize_Base();