(function( $ ){
	"use strict";
    var InspiusSampleSetup = {
        init : function() {
        	this.sampleDataInstall();
        	this.switchStyle();
        },
        switchStyle: function(){
        	$('#inspius-list-demo li').on('click', function() {
        		var $this = $(this);
        		var $style = $this.data('style');

        		$('#inspius-list-demo li').removeClass('active');

        		$this.addClass('active');

        		$('#inspius-theme-style').val($style);

        	});
        },
        sampleDataInstall: function(){
        	$('#inspius_sample_data .begin-install').on( 'click', function(){
        		if( confirm( $(this).data('confirm') ) ){
        			var _values = new Array();
        			var check_sample = false;
        			var style = $('#inspius-theme-style').val();

					$.each($("input[name='sample[]']:checked"), function() {
						var _vl = $(this).val();
						if( _vl == 'sample' ){
							check_sample = true;
						}else{
							_values.push(_vl);
						}
					});

					if( check_sample ){
						InspiusSampleSetup.ajaxInstallSample( _values, style );
						$('#inspius_sample_data').addClass('is-sample');
					}else{
						InspiusSampleSetup.ajaxInstallConfig( _values, style );
					}	
        		}
				return false;
					
        	} );
        },
        ajaxInstallSample: function(key, style){
        	$.ajax({
				url: ajaxurl,
				type: 'POST',
				dataType: 'JSON',
				data: {
					inspius_sample: key,
					action: 'inspius_install_sample_data',
					inspius_style : style,
				},
				beforeSend: function(){
					InspiusSampleSetup.beforeLoad();
				},
				success:function(response){
					console.log(response);
					if( response.install_config ){
						InspiusSampleSetup.ajaxInstallConfig( response.datas );
					}else{
						InspiusSampleSetup.afterLoad();
					}
				}
			});
        },
        ajaxInstallConfig: function(key, style){
        	$.ajax({
				url: ajaxurl,
				type: 'POST',
				// dataType: 'JSON',
				data: {
					inspius_sample: key,
					action: 'inspius_install_sample_config',
					inspius_style : style,
				},
				beforeSend: function(){
					InspiusSampleSetup.beforeLoad();
				},
				success:function(response){
					console.log(response);
					InspiusSampleSetup.afterLoad();
				}
			});
        },
        beforeLoad: function(){
        	$('#inspius_sample_data .success').removeClass('active');
        	$('#inspius_sample_data :input').prop('disabled', 'true');
        	$('#inspius_sample_data .loading').addClass('active');
        },
        afterLoad: function(){
        	$('#inspius_sample_data :input').removeAttr('disabled');
        	$('#inspius_sample_data .loading').removeClass('active');
        	if( $('#inspius_sample_data').hasClass('is-sample') ){
        		$('#inspius_sample_data .success-sample').addClass('active');
        	}else{
        		$('#inspius_sample_data .success-config').addClass('active');
        	}
        }
    };

    $(document).ready(function() {
    	InspiusSampleSetup.init();
    });


})( jQuery );