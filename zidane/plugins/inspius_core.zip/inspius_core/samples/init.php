<?php


class Inspius_Sample_Data {

	protected static $_instance;

	private $config;

	private $export = array();

	/**
	 * Main Inspius_Sample_Data Instance
	 *
	 * Ensures only one instance of Inspius_Sample_Data is loaded or can be loaded.
	 *
	 * @static
	 * @return Inspius_Sample_Data - Main instance
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function __construct() {

		$this->config = simplexml_load_file( INSPIUS_PLUGIN_URL . 'inspius.xml' );

		$this->init_ajax_option();

		// add_action( 'admin_menu', array( $this, 'init_menu_panel' ) );

	}

	public function init_menu_panel() {
		add_submenu_page( 
			'inspius-about', 
			'Inspius Sample', 
			'Import Config', 
			'export', 
			'inspius-sample', 
			array( $this, 'sample_template' ) 
		);
		
	}

	public function sample_template() {
		include_once( INSPIUS_PLUGIN_URL . 'samples/temp/template.php' );
	}

	private function set_up_function( $key, $style ) {
		$is = Inspius_Functions::instance();
		switch ( $key ) {
			case 'woocommerce':
				$this->setup_config_woocommerce();
				if ( $is->is_request( 'zoom_magnifier' ) ) {
					$this->setup_config_zoom_magnifier();
				}
				if ( $is->is_request( 'wishlist' ) ) {
					$this->setup_config_yith_wishlist();
				}
				break;
			case 'wpml_woocommerce':
				$this->setup_config_wpml_woocommerce();
				break;
			case 'mailchimp':
				$this->setup_config_mailchimp();
				break;
			case 'newsletter':
				$this->setup_config_newsletter();
				break;
			case 'theme_config':
				$this->setup_config_theme( $style );
				break;
			case 'revslider':
				$this->setup_config_revslider();
				break;
			case 'theme_widgets':
				$this->setup_config_widgets();
				break;
			case 'theme_options':
				$this->setup_config_theme_option( $style );
				break;
		}
	}

	public function get_list_action() {
		$is = Inspius_Functions::instance();
		?>
		<ul class="list-action">
			<?php if(false): ?>
			<li>
				<label>
					<input type="checkbox" class="checkbox" checked="checked" name="sample[]" value="sample"> Sample Content
				</label>
			</li>
			<?php endif; ?>
			<li>
				<label>
					<input type="checkbox" class="checkbox" checked="checked" name="sample[]" value="theme_config"> Theme Config
				</label>
			</li>
			<?php if ( $is->is_request( 'redux' ) ) { ?>
				<li>
					<label>
						<input type="checkbox" class="checkbox" checked="checked" name="sample[]" value="theme_options"> Theme Options Import
					</label>
				</li>
			<?php } ?>
			<li class="visible">
				<label>
					<input type="checkbox" class="checkbox" checked="checked" name="sample[]" value="theme_widgets"> Widget Import
				</label>
			</li>
			<?php if ( $is->is_request( 'revslider' ) ) { ?>
				<li class="visible">
					<label>
						<input type="checkbox" class="checkbox" checked="checked" name="sample[]" value="revslider"> Revolution Slider Import
					</label>
				</li>
			<?php } ?>
			<?php if ( $is->is_request( 'woocommerce' ) ) { ?>
				<li>
					<label>
						<input type="checkbox" class="checkbox" checked="checked" name="sample[]" value="woocommerce"> Woocommerce Config
					</label>
				</li>
			<?php } ?>

			<?php if ( $is->is_request( 'wpml-woocommerce' ) ) { ?>
				<li>
					<label>
						<input type="checkbox" class="checkbox" checked="checked" name="sample[]" value="wpml_woocommerce"> WooCommerce
						Multilingual Config
					</label>
				</li>
			<?php } ?>

			<?php if ( $is->is_request( 'mailchimp' ) ) { ?>
				<li>
					<label>
						<input type="checkbox" class="checkbox" checked="checked" name="sample[]" value="mailchimp"> MailChimp for WP
						Config
					</label>
				</li>
			<?php } ?>

			<?php if ( $is->is_request( 'newsletter' ) ) { ?>
				<li>
					<label>
						<input type="checkbox" class="checkbox" checked="checked" name="sample[]" value="newsletter"> MailPoet Config
					</label>
				</li>
			<?php } ?>

		</ul>
		<?php
	}

	private function setup_config_theme_option( $style = 'theme_option' ){
		$option_json = json_decode( wp_remote_retrieve_body( wp_remote_get( INSPIUS_PLUGIN_URI . 'samples/datas/options/' . $style . '.json' ) ), true );
		update_option( 'theme_option', $option_json );
	}

	private function setup_config_widgets(){
		global $wp_registered_sidebars;

		$widgets_json = INSPIUS_PLUGIN_URI . 'samples/datas/widgets/widget_data.json'; // widgets data file
		$widgets_json = wp_remote_get( $widgets_json );

		$json_data = $widgets_json['body'];

		$json_data = json_decode( $json_data, true );
		$sidebars_data = $json_data[0];
		$widget_data = $json_data[1];

		foreach ( $sidebars_data as $import_sidebar => $import_widgets ) :

			foreach ( $import_widgets as $import_widget ) :
				//if the sidebar exists
				if ( isset( $wp_registered_sidebars[$import_sidebar] ) ) :
					$title = trim( substr( $import_widget, 0, strrpos( $import_widget, '-' ) ) );
					$index = trim( substr( $import_widget, strrpos( $import_widget, '-' ) + 1 ) );
					$current_widget_data = get_option( 'widget_' . $title );
					$new_widget_name = $this->new_widget_name( $title, $index );
					$new_index = trim( substr( $new_widget_name, strrpos( $new_widget_name, '-' ) + 1 ) );

					if ( !empty( $new_widgets[ $title ] ) && is_array( $new_widgets[$title] ) ) {
						while ( array_key_exists( $new_index, $new_widgets[$title] ) ) {
							$new_index++;
						}
					}
					$current_sidebars[$import_sidebar][] = $title . '-' . $new_index;
					if ( array_key_exists( $title, $new_widgets ) ) {
						$new_widgets[$title][$new_index] = $widget_data[$title][$index];
						$multiwidget = $new_widgets[$title]['_multiwidget'];
						unset( $new_widgets[$title]['_multiwidget'] );
						$new_widgets[$title]['_multiwidget'] = $multiwidget;
					} else {
						$current_widget_data[$new_index] = $widget_data[$title][$index];
						$current_multiwidget = $current_widget_data['_multiwidget'];
						$new_multiwidget = isset($widget_data[$title]['_multiwidget']) ? $widget_data[$title]['_multiwidget'] : false;
						$multiwidget = ($current_multiwidget != $new_multiwidget) ? $current_multiwidget : 1;
						unset( $current_widget_data['_multiwidget'] );
						$current_widget_data['_multiwidget'] = $multiwidget;
						$new_widgets[$title] = $current_widget_data;
					}

				endif;
			endforeach;
		endforeach;
		if ( isset( $new_widgets ) && isset( $current_sidebars ) ) {
			update_option( 'sidebars_widgets', $current_sidebars );

			foreach ( $new_widgets as $title => $content )
				update_option( 'widget_' . $title, $content );

			return true;
		}
		return false;
	}

	private function new_widget_name($widget_name, $widget_index){
		$current_sidebars = get_option( 'sidebars_widgets' );
		$all_widget_array = array( );
		foreach ( $current_sidebars as $sidebar => $widgets ) {
			if ( !empty( $widgets ) && is_array( $widgets ) && $sidebar != 'wp_inactive_widgets' ) {
				foreach ( $widgets as $widget ) {
					$all_widget_array[] = $widget;
				}
			}
		}
		while ( in_array( $widget_name . '-' . $widget_index, $all_widget_array ) ) {
			$widget_index++;
		}
		$new_widget_name = $widget_name . '-' . $widget_index;
		return $new_widget_name;
	}

	private function setup_config_revslider(){
		$path = INSPIUS_PLUGIN_URL . 'samples/datas/sliders';
		if ($handle = opendir( $path )) {
		    while (false !== ($entry = readdir($handle))) {
		        if ($entry != "." && $entry != "..") {
		            $_FILES['import_file']['tmp_name']= $path . '/' . $entry;
		            $slider = new RevSlider();
					$response = $slider->importSliderFromPost(true, true);
		        }
		    }
		    closedir($handle);
		}
	}

	private function setup_config_wpml_woocommerce() {

		$set_option_currency = get_option( '_wcml_settings' );

		foreach ( $this->config->wpml_woocommerce->key as $node ) {
			$data = $this->get_config_data( $node );
			if ( is_array( $data['value'] ) ) {
				$set_option_currency[ $data['key'] ] = $data['value'][0];
			} else {
				$set_option_currency[ $data['key'] ] = $data['value'];
			}
		}

		update_option( '_wcml_settings', $set_option_currency );
		flush_rewrite_rules();
	}

	private function setup_config_mailchimp() {
		$my_post = array();

		// Check form exist
		$forms = mc4wp_get_forms( array( 'numberposts' => 1 ) );
		if ( count( $forms ) == 0 ) {
			// Add Form
			$my_post['post_type']    = 'mc4wp-form';
			$my_post['post_title']   = 'Inspius Test';
			$my_post['post_content'] = 'Form Demo';
			$my_post['post_status']  = 'publish';
			wp_insert_post( $my_post );

		}


		// Edit Form
		$args  = array(
			'post_type' => 'mc4wp-form',
		);
		$query = new WP_Query( $args );

		$my_post['ID'] = $query->post->ID;
		// setup value form
		foreach ( $this->config->mailchimp->key as $node ) {
			$data = $this->get_config_data( $node );
			if ( $data['key'] == "title" ) {
				$my_post['post_title'] = $data['value'];
			}
			if ( $data['key'] == "content" ) {
				$my_post['post_content'] = $data['value'];
			}
		}

		wp_update_post( $my_post );


		flush_rewrite_rules();
	}

	private function setup_config_newsletter() {

		foreach ( $this->config->newsletter->key as $node ) {
			$data = $this->get_config_data( $node );
			if ( $data['key'] == "title" ) {
				$form_title = $data['value'];
			}
			if ( $data['key'] == "content" ) {
				$form_data = $data['value'];
			}
		}
		echo $form_data;
		$model_forms = WYSIJA::get( 'forms', 'model' );
		$forms       = $model_forms->getRows();
		$form        = $forms[ count( $forms ) - 1 ];
		$model_forms->update( array(
			'name' => $form_title,
			'data' => $form_data
		), array( 'form_id' => (int) $form['form_id'] ) );

		flush_rewrite_rules();
	}

	private function setup_config_zoom_magnifier() {
		foreach ( $this->config->woocommerce->yith_zoom_magnifier->key as $node ) {

			$data = $this->get_config_data( $node );

			if ( $data['key'] == 'yith_wcmg_lens_opacity' || $data['key'] == 'yith_wcmg_slider_items' ) {
				$data['value'] = $data['value'][0];
			}
			update_option( $data['key'], $data['value'] );
		}

		flush_rewrite_rules();
	}

	private function setup_config_yith_wishlist() {

		foreach ( $this->config->woocommerce->yith_wishlist->key as $node ) {
			$data = $this->get_config_data( $node );
			update_option( $data['key'], $data['value'] );
		}

		flush_rewrite_rules();
	}

	private function setup_config_theme( $style = '' ){
		global $wpdb;
		$title_home = 'Home';
		switch ( $style ) {
			case 'cigarette-2':
				$title_home = 'Home 2';
				break;
			case 'cigarette-3':
				$title_home = 'Home 3';
				break;
		}

		$homepage = get_page_by_title( $title_home );
	    //$posts_page = get_page_by_title( 'Blog Large' );
	    if( isset( $homepage ) && $homepage->ID ) {
	        update_option('show_on_front', 'page');
	        @update_option( 'page_on_front', $homepage->ID ); // Front Page
	        //@update_option('page_for_posts', $posts_page->ID); // Blog Page
	    }

		$table_db_name = $wpdb->prefix . "terms";
		$rows = $wpdb->get_results("SELECT * FROM $table_db_name where  name='Main Menu'",ARRAY_A);
		$menu_ids = array();
		foreach($rows as $row) {
			$menu_ids[$row["name"]] = $row["term_id"] ;
		}

		if ( !has_nav_menu( 'mainmenu' ) ) {
			set_theme_mod( 'nav_menu_locations', array_map( 'absint', array( 
				'mainmenu' =>$menu_ids['Main Menu'] ,
			) ) );
		}
	}

	private function setup_export_array() {

		//get form mailchimp
		$forms = mc4wp_get_forms( array( 'numberposts' => 1 ) );

		//get option wpml_woocommerce
		$option_currency = get_option( '_wcml_settings' );

		//get form newsletter
		$model_forms     = WYSIJA::get( 'forms', 'model' );
		$get_forms       = $model_forms->getRows();
		$form_newsletter = $forms[ count( $get_forms ) - 1 ];

		//set data export
		$this->export = array(
			'woocommerce'         => array(
				'shop_catalog_image_size'                   => get_option( 'shop_catalog_image_size' ),
				'woocommerce_enable_myaccount_registration' => get_option( 'woocommerce_enable_myaccount_registration' )
			),
			'wpml_woocommerce'    => array(
				'trnsl_interface'           => $option_currency['trnsl_interface'],
				'products_sync_date'        => $option_currency['products_sync_date'],
				'products_sync_order'       => $option_currency['products_sync_order'],
				'file_path_sync'            => $option_currency['file_path_sync'],
				'enable_multi_currency'     => $option_currency['enable_multi_currency'],
				'currency_switcher_style'   => $option_currency['currency_switcher_style'],
				'wcml_curr_sel_orientation' => $option_currency['wcml_curr_sel_orientation'],
				'wcml_curr_template'        => $option_currency['wcml_curr_template'],
			),
			'mailchimp'           => array(
				'title'   => $forms[0]->name,
				'content' => $forms[0]->content,

			),
			'newsletter'          => array(
				'title'   => $form_newsletter['name'],
				'content' => $form_newsletter['data'],
			),
			'yith_zoom_magnifier' => array(
				'yith_wcmg_enable_plugin'        => get_option( 'yith_wcmg_enable_plugin' ),
				'yith_wcmg_enable_mobile'        => get_option( 'yith_wcmg_enable_mobile' ),
				'yith_wcmg_force_sizes'          => get_option( 'yith_wcmg_force_sizes' ),
				'yith_wcmg_zoom_width'           => get_option( 'yith_wcmg_zoom_width' ),
				'yith_wcmg_zoom_height'          => get_option( 'yith_wcmg_zoom_height' ),
				'woocommerce_magnifier_image'    => get_option( 'woocommerce_magnifier_image' ),
				'yith_wcmg_zoom_position'        => get_option( 'yith_wcmg_zoom_position' ),
				'yith_wcmg_zoom_mobile_position' => get_option( 'yith_wcmg_zoom_mobile_position' ),
				'yith_wcmg_loading_label'        => get_option( 'yith_wcmg_loading_label' ),
				'yith_wcmg_lens_opacity'         => get_option( 'yith_wcmg_lens_opacity' ),
				'yith_wcmg_softfocus'            => get_option( 'yith_wcmg_softfocus' ),
				'yith_wcmg_enableslider'         => get_option( 'yith_wcmg_enableslider' ),
				'yith_wcmg_slider_responsive'    => get_option( 'yith_wcmg_slider_responsive' ),
				'yith_wcmg_slider_items'         => get_option( 'yith_wcmg_slider_items' ),
				'yith_wcmg_slider_circular'      => get_option( 'yith_wcmg_slider_circular' ),
				'yith_wcmg_slider_items'         => get_option( 'yith_wcmg_slider_infinite' ),
			),
		);
	}

	private function setup_config_woocommerce() {
		// Set pages
		$woopages = array(
			'woocommerce_shop_page_id'            => 'Shop',
			'woocommerce_cart_page_id'            => 'Cart',
			'woocommerce_checkout_page_id'        => 'Checkout',
			'woocommerce_pay_page_id'             => 'Checkout &#8594; Pay',
			'woocommerce_thanks_page_id'          => 'Order Received',
			'woocommerce_myaccount_page_id'       => 'My Account',
			'woocommerce_edit_address_page_id'    => 'Edit My Address',
			'woocommerce_view_order_page_id'      => 'View Order',
			'woocommerce_change_password_page_id' => 'Change Password',
			'woocommerce_logout_page_id'          => 'Logout',
			'woocommerce_lost_password_page_id'   => 'Lost Password'
		);
		foreach ( $woopages as $woo_page_name => $woo_page_title ) {
			$woopage = get_page_by_title( $woo_page_title );
			if ( isset( $woopage->ID ) && $woopage->ID ) {
				update_option( $woo_page_name, $woopage->ID ); // Front Page
			}
		}

		// We no longer need to install pages
		$notices = array_diff( get_option( 'woocommerce_admin_notices', array() ), array( 'install', 'tracking' ) );
		update_option( 'woocommerce_admin_notices', $notices );

		// Wishlist Page
		$wishlist_page = get_page_by_title( 'Wishlist' );
		update_option( 'yith_wcwl_wishlist_page_id', $wishlist_page->ID );

		foreach ( $this->config->woocommerce->key as $node ) {
			$data = $this->get_config_data( $node );
			update_option( $data['key'], $data['value'] );
		}

		// Flush rules after install
		flush_rewrite_rules();

	}

	private function get_config_data( $node ) {
		$key  = (string) $node->attributes()->id;
		$data = $this->get_format_data( trim( $node ) );

		return array(
			'key'   => $key,
			'value' => $data,
		);
	}

	private function get_format_data( $data ) {
		$d = @json_decode( $data );
		if ( $d === null && json_last_error() !== JSON_ERROR_NONE ) {
			return (string) $data;
		}

		return (array) $d;

	}

	public function import_xml_data() {
		if ( ! defined( 'WP_LOAD_IMPORTERS' ) ) {
			define( 'WP_LOAD_IMPORTERS', true );
		}

		require_once ABSPATH . 'wp-admin/includes/import.php';
		$importer_error = false;

		if ( ! class_exists( 'WP_Importer' ) ) {
			$class_wp_importer = ABSPATH . 'wp-admin/includes/class-wp-importer.php';
			if ( file_exists( $class_wp_importer ) ) {
				require_once( $class_wp_importer );
			} else {
				$importer_error = true;
			}
		}

		if ( ! class_exists( 'WP_Import' ) ) {

			$class_wp_import = INSPIUS_PLUGIN_URL . 'samples/wordpress-importer/wordpress-importer.php';
			if ( file_exists( $class_wp_import ) ) {
				require( $class_wp_import );
			} else {
				$importer_error = true;
			}
		}

		if ( $importer_error ) {
			// return __( 'Import error! Please unninstall WP importer plugin and try again', 'inspius_core' );
			return false;
		} else {

			add_filter( 'intermediate_image_sizes_advanced', create_function( '', 'return array();' ) );

			$wp_import                    = new WP_Import();
			$wp_import->fetch_attachments = true;
			$filexml                      = INSPIUS_PLUGIN_URL . 'samples/datas/sample.xml';
			
			ob_start();
			$wp_import->import( $filexml );
			ob_end_clean();

			wp_delete_post( 1 );
		}

		// return __( 'Import Success!', 'inspius_core' );
		return true;
	}

	private function db( $data ) {
		echo '<pre>';
		print_r( $data );
		echo '</pre>';
		die;
	}

	private function init_ajax_option() {
		add_action( 'wp_ajax_inspius_install_sample_data', 		array( $this, 'install_sample_data' ) );
		add_action( 'wp_ajax_inspius_install_sample_config', 	array( $this, 'install_sample_config' ) );
		add_action( 'wp_ajax_inspius_set_sample_config', 		array( $this, 'init_export_config' ) );
	}

	public function install_sample_config() {
		$datas = $_POST['inspius_sample'];
		$style = isset( $_POST['inspius_style'] ) ? $_POST['inspius_style'] : '';
		foreach ( $datas as $value ) {
			$this->set_up_function( $value, $style );
		}
		exit();
	}

	public function install_sample_data() {
		$response = array(
			'install_config' => false,
			'datas'          => array(),
			'check_sample'   => false,
		);

		if ( isset( $_POST['inspius_sample'] ) ) {
			$response['install_config'] = true;
			$response['datas']          = $_POST['inspius_sample'];
		}

		$response['check_sample'] = $this->import_xml_data();

		print_r( json_encode( $response ) );

		exit();
	}

	public function init_export_config() {
		$this->setup_export_array();
		$filename = get_template_directory() . '/inspius.xml';
		global $wp_filesystem;
		if ( empty( $wp_filesystem ) ) {
			require_once( ABSPATH . '/wp-admin/includes/file.php' );
			WP_Filesystem();
		}
		$output = "<themeconfig>\n";

		foreach ( $this->export as $key => $section ) {
			$output .= "\t<{$key}>\n";
			foreach ( $section as $k => $value ) {
				if ( is_array( $value ) ) {
					$value = json_encode( $value );
					$output .= "\t\t<key id=\"{$k}\"><![CDATA[{$value}]]></key>\n";
				} else {
					$output .= "\t\t<key id=\"{$k}\">{$value}</key>\n";
				}
			}
			$output .= "\t</{$key}>\n";
		}


		$output .= '</themeconfig>';
		if ( ! $wp_filesystem->put_contents( $filename, $output ) ) {
			echo 'error saving file!';
		}
	}

}

Inspius_Sample_Data::instance();