<?php

/*==========================================================================
Init Megamenu
==========================================================================*/
define( 'INSPIUS_PLUGIN_MEGAMENU_PATH', INSPIUS_PLUGIN_URL . 'megamenu/' );

define( 'INSPIUS_PLUGIN_MEGAMENU_URL', INSPIUS_PLUGIN_URI . 'megamenu/' );

define( 'INSPIUS_PLUGIN_MEGAMENU_WIDGET', INSPIUS_PLUGIN_MEGAMENU_PATH .'widgets' );

define( 'INSPIUS_PLUGIN_MEGAMENU_TEMPLATE', INSPIUS_PLUGIN_MEGAMENU_PATH.'widget_templates' );

require_once ( INSPIUS_PLUGIN_MEGAMENU_PATH . 'includes/megamenu-base.php' );
require_once ( INSPIUS_PLUGIN_MEGAMENU_PATH . 'includes/params.php' );
require_once ( INSPIUS_PLUGIN_MEGAMENU_PATH . 'includes/megamenu-widget.php' );
require_once ( INSPIUS_PLUGIN_MEGAMENU_PATH . 'includes/shortcodebase.php' );
require_once ( INSPIUS_PLUGIN_MEGAMENU_PATH . 'includes/shortcodes.php' );
require_once ( INSPIUS_PLUGIN_MEGAMENU_PATH . 'includes/megamenu-ajax-action.php' );


if( !class_exists( 'Inspius_Megamenu_Editor' ) ){
	class Inspius_Megamenu_Editor{

		public static function instance(){
			static $_instance;
			if( !$_instance ){
				$_instance = new Inspius_Megamenu_Editor();
			}
			return $_instance;
		}

		public function __construct(){

			// Load ajax action
			Megamenu_Ajax_Action::instance();
			
			add_action( 'admin_menu', 				array( $this, 'admin_load_menu') );
			add_action( 'admin_enqueue_scripts',	array($this,'init_scripts') );

		}

		public function admin_load_menu(){
			//add_theme_page( 'inspius_core', "Megamenu Editor", 'switch_themes', 'inspius_megamenu', array($this,'mega_menu_page') );

			add_submenu_page( 
				'inspius-about', 
				'Megamenu Editor', 
				'Megamenu Editor', 
				'export', 
				'inspius-megamenu', 
				array( $this, 'mega_menu_page' ) 
			);
		}

		public function mega_menu_page(){
  			$wpos    		= Inspius_Megamenu_Shortcodes::instance();
  			$widgets 		= INSPIUS_PLUGIN_MEGAMENU_WIDGET::instance()->get_widgets();

  			$menus 			= wp_get_nav_menus( array( 'orderby' => 'id' ) );
			$option_menu 	= array();

		    foreach ( $menus as $menu_option ) {
		    	$option_menu[$menu_option->term_id] = $menu_option->name;
		    }

			require INSPIUS_PLUGIN_MEGAMENU_PATH . 'template/editor.php';
		}

		public function init_scripts(){
			if( isset($_GET['page']) && $_GET['page'] == 'inspius-megamenu' ){
				wp_enqueue_style(  'megamenu_core_css',	INSPIUS_PLUGIN_MEGAMENU_URL . 'assets/css/megamenu.min.css' );
				wp_enqueue_script( 'megamenu_core_js',	INSPIUS_PLUGIN_MEGAMENU_URL . 'assets/js/megamenu.min.js' );
			}
		}
	}

	global $inspius_megamenu;
	$inspius_megamenu = Inspius_Megamenu_Editor::instance();

}




