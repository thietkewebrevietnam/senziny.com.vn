<?php

if( Inspius_Functions::instance()->is_request( 'woocommerce' ) ){
	class PGL_Shortcode_Products extends PGL_Shortcode_Base{

		public function __construct( ){
			// add hook to convert shortcode to html.
			$this->name = str_replace( 'pgl_shortcode_','',strtolower( __CLASS__ ) );
			$this->key = 'pgl_'.$this->name;
			parent::__construct( );
		}

		/**
		 * $data format is object field of megamenu_widget record.
		 */
		public function getButton( $data=null ){
			$button = array(
				'icon'	 => 'image',
				'title' => __( 'Products', 'inspius_core' ),
				'desc'  => __( 'Display Products', 'inspius_core' ),
				'name'  => $this->name
			);

			return $button;
		}

		public function getOptions( ){
			$this->options[] = array(
				"type" 		=> "text",
				"label" 	=> __("Widget Title", 'inspius_core'),
				"id" 		=> "title",
				"default" 	=> ''
			);
		    $this->options[] = array(
		        'label' 	=> __('Type','inspius_core'),
		        'id' 		=> 'type',
		        'type' 		=> 'select',
		        'options'   => array(
								'recent_product' 	=> __('Recent Products', 'inspius_core'),
								'best_selling' 		=> __('Best Selling', 'inspius_core'),
								'featured_product'	=> __('Featured Products', 'inspius_core'),
								'top_rate' 			=> __('Top Rate', 'inspius_core'),
								'on_sale' 			=> __('On Sale', 'inspius_core'),
								'recent_review' 	=> __('Recent Review', 'inspius_core'), 
								'deals' 			=> __('Product Deals', 'inspius_core') 
							),
	        );
	        $this->options[] = array(
		        'label' 	=> __('Category','inspius_core'),
		        'id' 		=> 'category',
		        'type' 		=> 'select',
		        'options'   => $this->get_list_categories(),
	        );
	        $this->options[] = array(
		        'label' 	=> __('Layout','inspius_core'),
		        'id' 		=> 'style',
		        'type' 		=> 'select',
		        'options'   => array( 
			        				'grid' => 'Grid',
			        				'list' => 'List'
		        				)
	        );

	        $this->options[] = array(
		        'label' 	=> __('Columns count','inspius_core'),
		        'id' 		=> 'columns',
		        'type' 		=> 'select',
		        'options'   => array(
		        					'6' => 6,
		        					'5' => 5,
		        					'4' => 4,
		        					'3' => 3, 
		        					'2' => 2, 
		        					'1' => 1
		        				)
	        );

	        $this->options[] = array(
				"type" 		=> "text",
				"label" 	=> __("Number of products to show", 'inspius_core'),
				"id" 		=> "per_page",
				"default" 	=> '4'
			);
		}

		private function get_list_categories(){
			global $wpdb;
			$sql = "SELECT a.name,a.slug,a.term_id FROM $wpdb->terms a JOIN  $wpdb->term_taxonomy b ON (a.term_id= b.term_id ) where b.taxonomy = 'product_cat'";
			$results = $wpdb->get_results($sql);
			$value = array( 'all' => 'All' );
			foreach ($results as $vl) {
				$value[$vl->slug] = $vl->name;
			}

			return $value;
		}

	}
}