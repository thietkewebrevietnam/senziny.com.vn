<?php

	class PGL_Shortcode_Sidebar extends PGL_Shortcode_Base{

		public function __construct( ){
			// add hook to convert shortcode to html.
			$this->name = str_replace( 'pgl_shortcode_','',strtolower( __CLASS__ ) );
			$this->key = 'pgl_'.$this->name;

			parent::__construct( );
		}


		/**
		 * $data format is object field of megamenu_widget record.
		 */
		public function getButton( $data=null ){
			$button = array(
				'icon'	 => 'sidebar',
				'title' => __( 'Sidebar Embeded','inspius_core' ),
				'desc'  => __( 'Embeded widgets in a sidebar','inspius_core' ),
				'name'  => $this->name
			);
			return $button;
		}

		public function getOptions( ){

		    $this->options[] = array(
		        'label' 	=> __('Sidebar', 'inspius_core'),
		        'id' 		=> 'sidebar',
		        'type' 		=> 'sidebars',
		        'explain'	=> __( 'Display all widgets on selected sidebar', 'inspius_core' )
	        );

	        $this->options[] = array(
		        'label' 	=> __('Addition Class', 'inspius_core'),
		        'id' 		=> 'class',
		        'type' 		=> 'text',
		        'explain'	=> __( 'Using to make own style', 'inspius_core' ),
		        'default'	=> '',
		        'hint'		=> '',
	        );
		}
	}
?>