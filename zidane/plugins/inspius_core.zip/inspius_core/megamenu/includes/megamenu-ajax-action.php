<?php


class Megamenu_Ajax_Action{

	public static function instance(){
		static $_instance;
		if( !$_instance ){
			$_instance = new Megamenu_Ajax_Action();
		}
		return $_instance;
	}


	public function __construct(){
		add_action( 'wp_ajax_is_shortcode_button', array($this,'ajax_shortcode_button') );
		add_action( 'wp_ajax_is_shortcode_save', array($this,'ajax_shortcode_save') );
		add_action( 'wp_ajax_is_shortcode_delete', array($this,'ajax_shortcode_delete') );
		add_action( 'wp_ajax_is_list_shortcodes', array($this,'show_list_shortcodes') );
		
		// Ajax Load Menu
		add_action( 'wp_ajax_is_megamenu_editor', array($this,'ajax_load_megamenu_admin') );
		// Save Config
		add_action( 'wp_ajax_is_save_megamenu_config', array($this,'ajax_save_megamenu_config') );
		// Remove Config
		add_action( 'wp_ajax_is_remove_megamenu_config', array($this,'ajax_remove_megamenu_config') );
		// Ajax Load Widget
		add_action( 'wp_ajax_is_load_widgets', array($this,'ajax_load_widget_menu') );
		// Backup
		add_action( 'wp_ajax_is_megamenu_backup', array($this,'ajax_megamenu_backup') );
	}


	public function ajax_load_widget_menu(){
		if( isset($_POST['widget_id']) ){
			$widget =$_POST['widget_id'];
			$dwidgets = INSPIUS_PLUGIN_MEGAMENU_WIDGET::instance()->loadWidgets();
			$shortcode =   Inspius_Megamenu_Shortcodes::instance();
			$output = '';
			$o = $dwidgets->getWidgetById( $widget );
			if( $o ){
				$output .= '<div class="pgl-module module">';
				$output .= $shortcode->getButtonByType( $o->type, $o );
				$output .= '</div>';
			}
			echo '' . $output;
		}
		exit();
	}

	public function ajax_megamenu_backup(){
		global $wpdb;
        $backup_options = array();
       	$locations = get_nav_menu_locations();
       	

        $backup_options['menu'] = get_option( "IS_MEGAMENU_DATA_".$locations['mainmenu'],'{}' );

        $sql = ' SELECT * FROM '.$wpdb->prefix.'megamenu_widgets ';
	 	$rows = $wpdb->get_results( $sql );
	 	$widgets = array();
	 	if( $rows ){
	 		foreach( $rows as $i => $row ){
	 			$widgets[] = $row;
	 		}
	 	}
	 	$backup_options['widgets'] = $widgets;

        $content = json_encode( $backup_options );
        
        header( 'Content-Description: File Transfer' );
        header( 'Content-type: application/txt' );
        header( 'Content-Disposition: attachment; filename="megamenu_options_backup_' . date( 'd-m-Y' ) . '.json"' );
        header( 'Content-Transfer-Encoding: binary' );
        header( 'Expires: 0' );
        header( 'Cache-Control: must-revalidate' );
        header( 'Pragma: public' );

        echo '' . $content;

        exit;
	}

	public function ajax_remove_megamenu_config(){
		$menuid = $_GET['menuid'];
		update_option( 'IS_MEGAMENU_DATA_'.$menuid, '{}' );
		die();
	}

	public function ajax_load_megamenu_admin(){
		$menuid = isset($_GET['menuid'])?$_GET['menuid']:false;
	    $menu_build = new Megamenu_Buider($menuid);
		$menu_build_options = array('settings'=>json_decode( get_option( 'IS_MEGAMENU_DATA_'.$menuid ),true),'params'=>array());
	    die($menu_build->output($menu_build_options));
	}

	public function ajax_save_megamenu_config(){
		$menuid = $_POST['menuid'];
		$config = stripslashes($_POST['config']);
		update_option( 'IS_MEGAMENU_DATA_'.$menuid , $config );
		die();
	}

	public function ajax_shortcode_delete(){
		if(isset($_POST['id']) && $_POST['id']!=''){
			$obj = INSPIUS_PLUGIN_MEGAMENU_WIDGET::instance();
			$obj->delete($_POST['id']);
			echo esc_attr($_POST['id']);
		}else{
			echo false;
		}
		exit();
	}

	public function ajax_shortcode_button(){
		$obj = Inspius_Megamenu_Shortcodes::instance();

		if( isset( $_REQUEST['id'] ) ){
			$obj->getShortcode($_REQUEST['type'])->renderForm($_REQUEST['type'],$_REQUEST['id']);
		}else{
			$obj->getShortcode($_REQUEST['type'])->renderForm($_REQUEST['type']);
		}
		exit();
	}

	public function ajax_shortcode_save(){
		$id = (int)$_POST['shortcodeid'];
		$obj = Inspius_Megamenu_Shortcodes::instance();
		$type = $_POST['shortcodetype'];
		$name = $_POST['shortcode_name'];
		$inputs = serialize($_POST['pgl_input']);
		$response = array();
		if($id==0){
			$response['type']='insert';
			$response['id']= $this->insert_megamenu_table( $name, $type, $inputs );
			$response['title']=$name;
			$response['message'] = __('Widgets published','inspius_core');
			$response['type_widget'] = $type;
		}else{
			$response['type']='update';
			$response['message'] = __('Widgets updated','inspius_core');
			$response['title']=$name;
			$response['id']=$id;
			$this->update_mega_menu_table( $id, $name, $type, $inputs );
		}
		echo json_encode($response);
		exit();
	}

	public function update_mega_menu_table($id,$name,$type,$shortcode){
		global $wpdb;
		$table_name = $wpdb->prefix . "megamenu_widgets";
		$wpdb->update(
			$table_name,
			array(
                'name' => $name,
				'type' => $type,
				'params' => $shortcode,
			),
			array( 'id' => $id ),
			array(
				'%s',
				'%s',
				'%s'
			),
			array( '%d' )
		);
	}

	public function insert_megamenu_table($name,$type,$shortcode){
		global $wpdb;
		$table_name = $wpdb->prefix . "megamenu_widgets";
		$wpdb->replace(
			$table_name,
			array(
                'name' => $name,
				'type' => $type,
				'params' => $shortcode,
			),
			array(
		        '%s',
				'%s',
				'%s'
			)
		);
		return $wpdb->insert_id;
	}

	public function show_list_shortcodes(){
		$obj =   Inspius_Megamenu_Shortcodes::instance();
		$shortcodes =$obj->getButtons();
		require INSPIUS_PLUGIN_MEGAMENU_PATH. 'template/shortcodes.php';
	 	exit();
	}
}