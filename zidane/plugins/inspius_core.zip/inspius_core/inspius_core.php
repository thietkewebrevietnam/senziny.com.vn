<?php
/**
 * Plugin Name: Inspius Core
 * Plugin URI: http://inspius.com/
 * Description: This is our companion plugin that is required to use Zidane. Please make sure this is always installed and activated.
 * Version: 1.0
 * Author: Inspius Team
 * Author URI: http://inspius.com/
 * License: http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Text Domain: inspius_core
 */

define( 'INSPIUS_PLUGIN_URL', plugin_dir_path( __FILE__ ) );
define( 'INSPIUS_PLUGIN_URI', plugin_dir_url( __FILE__ ) );

class Inspius_Plugin_Core{

	public static $_instance;

	private $check_url, $theme_option;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function __construct(){
		
		$this->theme_option = get_option( 'theme_option' );
		$this->check_url 	= 'http://theme.inspius.com/server_update/zidane/info.json';

		// Setup Menu
		add_action( 'admin_menu', array( $this, 'init_menu_panel' ) );

		$this->include_core();

		add_action( 'init', array( $this, 'register_footer' ) );
		$this->update_plugin();
		
	}

	private function include_core(){
		include_once 'plugin-updates/plugin-update-checker.php';
		include_once 'widgets/init.php';
		include_once 'customize/init.php';
		if( isset( $this->theme_option['styling_frontend'] ) && $this->theme_option['styling_frontend'] ){
			include_once 'customize/frontend.php';
		}
		if( is_admin() ){
			include_once 'samples/init.php';
		}
		//Megamenu
		include_once 'megamenu/megamenu.php';
	}

	public function init_menu_panel(){
		add_menu_page( 
			__( 'About', 'inspius_core' ), 
			'Zidane', 
			'export', 
			'inspius-about', 
			array( $this, 'sample_template' ), 
			INSPIUS_PLUGIN_URI . 'samples/images/icon-inspius.png',
			59 
		);
	}

	public function sample_template() {
		include_once( INSPIUS_PLUGIN_URL . 'template/about.php' );
	}

	private function update_plugin(){
		$updatechecker = PucFactory::buildUpdateChecker(
			$this->check_url,
			__FILE__
		);
		$updatechecker->addQueryArgFilter( array( $this, 'get_secretkey' ) );
	}

	public function get_secretkey($query){
		$query['secret'] = 'foo';
		return $query;
	}

	public function register_footer(){
		$labels = array(
		    'name' 					=> __( 'Footer', 					'inspius_core' ),
		    'singular_name'		 	=> __( 'Footer', 					'inspius_core' ),
		    'add_new' 				=> __( 'Add New Footer', 			'inspius_core' ),
		    'add_new_item' 			=> __( 'Add New Footer', 			'inspius_core' ),
		    'edit_item' 			=> __( 'Edit Footer', 				'inspius_core' ),
		    'new_item' 				=> __( 'New Footer', 				'inspius_core' ),
		    'view_item' 			=> __( 'View Footer', 				'inspius_core' ),
		    'search_items' 			=> __( 'Search Footers', 			'inspius_core' ),
		    'not_found' 			=> __( 'No Footers found', 			'inspius_core' ),
		    'not_found_in_trash' 	=> __( 'No Footers found in Trash', 'inspius_core' ),
		    'parent_item_colon' 	=> __( 'Parent Footer:', 			'inspius_core' ),
		    'menu_name' 			=> __( 'Footers', 					'inspius_core' ),
		);

		$args = array(
			'labels' 				=> $labels,
			'hierarchical' 			=> true,
			'description' 			=> __( 'List Footer', 'inspius_core' ),
			'supports' 				=> array( 'title', 'editor' ),
			'public' 				=> true,
			'show_ui' 				=> true,
			'show_in_menu' 			=> true,
			'menu_position' 		=> 5,
			'show_in_nav_menus' 	=> false,
			'publicly_queryable' 	=> false,
			'exclude_from_search' 	=> false,
			'has_archive' 			=> false,
			'query_var' 			=> true,
			'can_export' 			=> true,
			'rewrite' 				=> false
		);
		// Create post_type footer
		register_post_type( 'footer', $args );
	}
}

new Inspius_Plugin_Core();